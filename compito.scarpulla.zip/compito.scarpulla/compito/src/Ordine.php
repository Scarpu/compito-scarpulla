<?php

class Ordine
{
    public $numero_ordine;
    public $data;
    public $importo_totale;
    public $articoli_venduti;

    public function __construct($numero_ordine, $data, $importo_totale, $articoli_venduti)
    {
        $this->numero_ordine = $numero_ordine;
        $this->data = $data;
        $this->importo_totale = $importo_totale;
        $this->articoli_venduti = $articoli_venduti;
    }
}

?>