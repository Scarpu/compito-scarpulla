<?php
class ArticoloVenduto {
    private $id;
    private $prezzo_di_vendita;
    private $quantita_acquistata;

    public function __construct($id, $prezzo_di_vendita, $quantita_acquistata) {
        $this->id = $id;
        $this->prezzo_di_vendita = $prezzo_di_vendita;
        $this->quantita_acquistata = $quantita_acquistata;
    }

    
}
?>