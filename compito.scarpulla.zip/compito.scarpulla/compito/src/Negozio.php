<?php

class Negozio  {
    private $nome;
    private $telefono;
    private $indirizzo;
    private $url;
    private $p_iva;

    public function __construct($nome, $telefono, $indirizzo, $url, $p_iva) {
        $this->nome = $nome;
        $this->telefono = $telefono;
        $this->indirizzo = $indirizzo;
        $this->url = $url;
        $this->p_iva = $p_iva;
    }

}
