<?php
use Slim\Factory\AppFactory;

require __DIR__ . '/vendor/autoload.php';

$app = AppFactory::create();
$app->get('/Negozio', 'NegozioController:getNegozio');
$app->get('/Articoli', 'ArticoloController:getArticoli');
$app->get('/Articoli/{id}', 'ArticoloController:getArticolo');
$app->get('/Ordini', 'OrdineController:getOrdini');
$app->get('/Ordini/{numero_ordine}', 'OrdineController:getOrdine');
$app->run();
?>