<?php

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

class NegozioController {
    private $negozio;

    public function __construct() {
        
        $this->negozio = new Negozio("Scarpulla Company", "1234567890", "Via Diaz 123", "http://www.Scarpulla.com", "12345678901");
    }

    public function getNegozio(Request $request, Response $response, $args) {
        $response->getBody()->write(json_encode($this->negozio, JSON_PRETTY_PRINT));
        return $response->withHeader('Content-Type', 'application/json');
    }
}
