<?php

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

class ArticoloController {
    private $articoli;

    public function __construct() {
        
        $this->articoli = [
            new Articolo(1, "Articolo 1", "Descrizione articolo 1", 100),
            new Articolo(2, "Articolo 2", "Descrizione articolo 2", 200),
            new Articolo(3, "Articolo 3", "Descrizione articolo 3", 150)
        ];
    }

    public function getArticoli(Request $request, Response $response, $args) {
        $response->getBody()->write(json_encode($this->articoli, JSON_PRETTY_PRINT));
        return $response->withHeader('Content-Type', 'application/json');
    }

    public function getArticolo(Request $request, Response $response, $args) {
        $id = $args['id'];
        foreach ($this->articoli as $articolo) {
            if ($articolo->getId() == $id) {
                $response->getBody()->write(json_encode($articolo, JSON_PRETTY_PRINT));
                return $response->withHeader('Content-Type', 'application/json');
            }
        }
        return $response->withStatus(404)->write('Articolo non trovato');
    }
}
