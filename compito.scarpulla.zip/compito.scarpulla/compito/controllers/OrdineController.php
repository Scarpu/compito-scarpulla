<?php

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

class OrdineController {
    private $ordini;

    public function __construct() {
        
        $this->ordini = [];
    }

    public function getOrdini(Request $request, Response $response, $args) {
        $response->getBody()->write(json_encode($this->ordini, JSON_PRETTY_PRINT));
        return $response->withHeader('Content-Type', 'application/json');
    }

    public function getOrdine(Request $request, Response $response, $args) {
        $numero_ordine = $args['numero_ordine'];
        foreach ($this->ordini as $ordine) {
            if ($ordine->getNumeroOrdine() == $numero_ordine) {
                $response->getBody()->write(json_encode($ordine, JSON_PRETTY_PRINT));
                return $response->withHeader('Content-Type', 'application/json');
            }
        }
        return $response->withStatus(404)->write('Ordine non trovato');
    }

    
}

?>